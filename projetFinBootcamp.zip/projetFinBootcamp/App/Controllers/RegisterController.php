<?php
require("../App/Models/register.php");

class RegisterController {
    //variable pour instancier la classe users
    public $model;

    //variables du formulaire
    public $user_id;
    public $user_firstname;
    public $user_lastname;
    public $user_email;
    public $user_password;
    public $confirm_pwd;
    public $user_role; 
    public $service_id; 

    public function sanitize($verif)
    {
        $verif = trim($verif);
        $verif = stripcslashes($verif);
        $verif = htmlspecialchars($verif);
        
        return $verif;
    }

    public function empty($data) {
     
        $data = $this->sanitize($_POST["firstname"], $_POST["lastname"], $_POST["email"], $_POST["password"], $_POST["user_role"], $_POST["service"]);

        if (empty($data)) {
            header("Location:/retrieve/addUsers");
            exit();
        } else {

            $this->user_firstname = $this->sanitize($_POST["firstname"]);
            $this->user_lastname = $this->sanitize($_POST["lastname"]);
            $this->user_email = $this->sanitize($_POST["email"]);
            $this->user_password = $this->sanitize($_POST["password"]);
            $this->user_role = $this->sanitize($_POST["user_role"]); 
            $this->service_id = $this->sanitize($_POST["service"]);            

        }
        return $data;
    }

    public function insertUsers() {
        if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["ajouter"]))
        {
            $this->user_firstname = $this->empty($_POST["firstname"]);
            $this->user_lastname = $this->empty($_POST["lastname"]);
            $this->user_email = $this->empty($_POST["email"]);
            $this->user_password = $this->empty($_POST["password"]);
            $this->user_role = $_POST["user_role"];
            $this->service_id = $_POST["service"];

            // echo $this->service_id;
            // exit();

            $this->model = new Register();
            $array = $this->model->VerifyUsers($this->user_email);

            $lenght = count($array);
            if($lenght>0) {
                header("Location:/retrieve/addUsers?user_exist");
                exit();

            } else if($this->password === $this->confirm_pwd) {
                $this->model->findInsertUser($this->user_firstname, $this->user_lastname,$this->user_email,$this->user_password, $this->user_role,$this->service_id);
                header("Location:/retrieve/showUsers");
                exit();
                
            }else {
                header("Location:/retrieve/addUsers?passwordIncorrect");
                exit();
            }
        }

    }

    public function updateUsers() {
        if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["modifier"]))
        {
            $this->user_id = $_POST["user_id"];
            $this->user_firstname = $this->empty($_POST["firstname"]);
            $this->user_lastname = $this->empty($_POST["lastname"]);
            $this->user_email = $this->empty($_POST["email"]);

            $this->model = new Register();
            $this->model->updateUsers($this->user_id, $this->user_firstname, $this->user_lastname, $this->user_email);

            header("Location:/retrieve/showUsers");
            exit();
                
        }

    }

    

    public function selectServiceUser() {
        $this->model = new Register();
        $stmt = $this->model->selectService();
        return $stmt;  
    }

    public function showUsers() {
        $this->model = new Register();
        $array = $this->model->showUsers();
        return $array;
    }

    public function deleteUsers() {
        if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete"])) {
            $this->user_id = $_POST["user_id"];
            $this->model = new Register();
            $this->model->deleteUsers($this->user_id);
            header("Location:/retrieve/showUsers");
            exit();
        }
    }
}

?>


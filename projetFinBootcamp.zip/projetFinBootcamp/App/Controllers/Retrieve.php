<?php

class Retrieve {
    public function home() {
        require("../App/Views/users/login.php");
    }

    public function index() {
        require("../App/Views/users/usersPage.php");
    }

    public function addUsers() {
        require("../App/Views/admin/addUsers.php");
    }

    public function showUsers() {
        require("../App/Views/admin/showUser.php");
    }

    public function showAdmin() {
        require("../App/Views/admin/admin.php");
    }

    public function addService() {
        require("../App/Views/admin/servicePage.php");
    }

    public function addSalle() {
        require("../App/Views/admin/sallePage.php");
    }

    public function showPlanning() {
        require("../App/Views/users/detailPlanning.php");
    }
    public function addEVent() {
        require("../App/Views/users/addEVent.php");
    }

 
}  